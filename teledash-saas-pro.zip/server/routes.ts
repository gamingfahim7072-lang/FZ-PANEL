import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import {
  db,
  User,
  TelegramBot,
  Product,
  Order,
  LicenseKey,
  DigitalFile,
  Customer,
  Broadcast,
  Coupon,
  ProductCategory,
  BotSettings,
  BotMenu,
  BotButton,
  ResellerApplication,
  BotFaq,
  BotVersion,
  BotPaymentConfig,
  MediaItem,
  PaymentProof,
  ProductPackage
} from './db.js';
import { CryptoService } from './crypto.js';
import {
  authenticate,
  optionalAuthenticate,
  requireRole,
  requireActiveSubscription,
  assertOwnership,
  rateLimit,
  logAudit,
  AuthenticatedRequest
} from './auth.js';
import { TelegramService } from './telegram.js';
import { PaymentService } from './payment.js';

export const apiRouter = Router();

// File upload configuration with security checks
const uploadDir = path.join(process.cwd(), 'data', 'uploads');
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const randomHex = CryptoService.generateRandomToken(16);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `sec-${Date.now()}-${randomHex}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB
  fileFilter: (_req, file, cb) => {
    // Prevent executable files from running
    const forbiddenExts = ['.exe', '.bat', '.cmd', '.sh', '.msi', '.vbs', '.com'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (forbiddenExts.includes(ext)) {
      return cb(new Error('Executable file types are restricted for security reasons.'));
    }
    cb(null, true);
  }
});

// ==========================================
// 1. AUTHENTICATION & PROFILE ROUTES
// ==========================================

apiRouter.post('/auth/register', rateLimit({ max: 15, windowMs: 60000 }), async (req: Request, res: Response) => {
  try {
    const { email, password, full_name, referral_code } = req.body;

    if (!email || !password || !full_name) {
      return res.status(400).json({ success: false, error: 'Email, password, and full name are required.' });
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
    }

    if (String(password).length < 6) {
      return res.status(400).json({ success: false, error: 'Password must be at least 6 characters long.' });
    }

    // Check if user already exists
    const existing = db.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(400).json({ success: false, error: 'An account with this email address already exists.' });
    }

    const password_hash = await CryptoService.hashPassword(password);
    const nowStr = new Date().toISOString();
    const myReferralCode = CryptoService.generateReferralCode(8);

    // Verify referrer if provided
    let referredBy: string | undefined;
    if (referral_code) {
      const refUser = db.users.find(u => u.referral_code.toUpperCase() === String(referral_code).trim().toUpperCase());
      if (refUser) {
        referredBy = refUser.id;
      }
    }

    const newUser: User = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      email: cleanEmail,
      password_hash,
      role: 'CUSTOMER',
      full_name: String(full_name).trim(),
      is_email_verified: true,
      two_factor_enabled: false,
      referral_code: myReferralCode,
      referred_by: referredBy,
      reseller_status: 'NONE',
      reseller_commission_rate: 15,
      reseller_balance: 0,
      created_at: nowStr,
      updated_at: nowStr
    };

    db.users.push(newUser);

    // Give a 14-day free Starter trial so user can start testing immediately!
    const trialExpiry = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
    db.subscriptions.push({
      id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      user_id: newUser.id,
      plan_id: 'plan-starter',
      billing_cycle: 'MONTHLY',
      amount: 0,
      currency: 'INR',
      status: 'ACTIVE',
      start_date: nowStr,
      expiry_date: trialExpiry,
      auto_renew: false,
      created_at: nowStr,
      updated_at: nowStr
    });

    db.saveImmediately();

    const token = CryptoService.generateJwt({ userId: newUser.id, role: newUser.role });

    logAudit({
      userId: newUser.id,
      userEmail: newUser.email,
      action: 'USER_REGISTERED',
      resourceType: 'USER',
      resourceId: newUser.id,
      req
    });

    return res.json({
      success: true,
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        full_name: newUser.full_name,
        role: newUser.role,
        referral_code: newUser.referral_code,
        reseller_status: newUser.reseller_status,
        reseller_balance: newUser.reseller_balance
      }
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ success: false, error: 'Registration failed. Please try again.' });
  }
});

apiRouter.post('/auth/login', rateLimit({ max: 20, windowMs: 60000 }), async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required.' });
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const user = db.users.find(u => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const isMatch = await CryptoService.comparePassword(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const token = CryptoService.generateJwt({ userId: user.id, role: user.role });

    // Find active subscription
    const activeSub = db.subscriptions
      .filter(s => s.user_id === user.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

    logAudit({
      userId: user.id,
      userEmail: user.email,
      action: 'USER_LOGIN',
      resourceType: 'SESSION',
      resourceId: user.id,
      req
    });

    return res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        referral_code: user.referral_code,
        reseller_status: user.reseller_status,
        reseller_balance: user.reseller_balance,
        two_factor_enabled: user.two_factor_enabled
      },
      subscription: activeSub || null
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
  }
});

apiRouter.get('/auth/me', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const subscription = req.subscription;
  const currentPlan = subscription ? db.subscription_plans.find(p => p.id === subscription.plan_id) : null;

  // Compute resource counts for tenant quotas
  const botCount = db.telegram_bots.filter(b => b.owner_id === user.id).length;
  const productCount = db.products.filter(p => p.owner_id === user.id).length;

  return res.json({
    success: true,
    user: {
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      role: user.role,
      referral_code: user.referral_code,
      reseller_status: user.reseller_status,
      reseller_balance: user.reseller_balance,
      two_factor_enabled: user.two_factor_enabled,
      created_at: user.created_at
    },
    subscription: subscription ? {
      ...subscription,
      plan: currentPlan
    } : null,
    usage: {
      bots: botCount,
      max_bots: currentPlan?.max_bots || 1,
      products: productCount,
      max_products: currentPlan?.max_products || 15
    }
  });
});

apiRouter.post('/auth/change-password', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { current_password, new_password } = req.body;
    const user = req.user!;

    if (!current_password || !new_password) {
      return res.status(400).json({ success: false, error: 'Current and new password are required.' });
    }

    const isMatch = await CryptoService.comparePassword(current_password, user.password_hash);
    if (!isMatch) {
      return res.status(400).json({ success: false, error: 'Current password does not match.' });
    }

    if (String(new_password).length < 6) {
      return res.status(400).json({ success: false, error: 'New password must be at least 6 characters.' });
    }

    user.password_hash = await CryptoService.hashPassword(new_password);
    user.updated_at = new Date().toISOString();
    db.save();

    logAudit({
      userId: user.id,
      action: 'PASSWORD_CHANGED',
      resourceType: 'USER',
      resourceId: user.id,
      req
    });

    return res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 2. DASHBOARD & ANALYTICS ROUTES
// ==========================================

apiRouter.get('/dashboard/stats', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const isSuperAdmin = user.role === 'SUPER ADMIN' || user.role === 'ADMIN';

    // Multi-tenant isolation: filter strictly by owner_id unless admin
    const userBots = isSuperAdmin ? db.telegram_bots : db.telegram_bots.filter(b => b.owner_id === user.id);
    const botIds = new Set(userBots.map(b => b.id));

    const userOrders = isSuperAdmin ? db.orders : db.orders.filter(o => o.owner_id === user.id || botIds.has(o.bot_id));
    const userProducts = isSuperAdmin ? db.products : db.products.filter(p => p.owner_id === user.id);
    const userCustomers = isSuperAdmin ? db.customers : db.customers.filter(c => c.owner_id === user.id || botIds.has(c.bot_id));

    const totalRevenue = userOrders
      .filter(o => o.status === 'DELIVERED' || o.status === 'PAID')
      .reduce((sum, o) => sum + (o.total_amount || 0), 0);

    const successfulOrders = userOrders.filter(o => o.status === 'DELIVERED' || o.status === 'PAID').length;
    const pendingOrders = userOrders.filter(o => o.status === 'PENDING' || o.status === 'PROCESSING').length;

    // Recent 7 days chart data calculation
    const dailyMap = new Map<string, { date: string; revenue: number; orders: number }>();
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      dailyMap.set(dateStr, { date: dateStr, revenue: 0, orders: 0 });
    }

    for (const order of userOrders) {
      if (order.created_at) {
        const dateStr = order.created_at.split('T')[0];
        if (dailyMap.has(dateStr)) {
          const entry = dailyMap.get(dateStr)!;
          if (order.status === 'DELIVERED' || order.status === 'PAID') {
            entry.revenue += order.total_amount || 0;
            entry.orders += 1;
          }
        }
      }
    }

    const chartData = Array.from(dailyMap.values());
    const recentOrders = userOrders.slice(0, 8);

    return res.json({
      success: true,
      stats: {
        totalRevenue,
        totalOrders: userOrders.length,
        successfulOrders,
        pendingOrders,
        totalCustomers: userCustomers.length,
        connectedBots: userBots.filter(b => b.status === 'CONNECTED').length,
        totalProducts: userProducts.length,
        chartData,
        recentOrders
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. SUBSCRIPTION & PAYMENT CHECKOUT
// ==========================================

apiRouter.get('/subscription/plans', async (_req: Request, res: Response) => {
  const activePlans = db.subscription_plans.filter(p => p.status === 'ACTIVE');
  return res.json({ success: true, plans: activePlans });
});

apiRouter.post('/subscription/create-order', authenticate, rateLimit({ max: 15, windowMs: 60000 }), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { planId, billingCycle, provider } = req.body;
    const user = req.user!;

    if (!planId || !billingCycle) {
      return res.status(400).json({ success: false, error: 'Plan ID and billing cycle (MONTHLY or YEARLY) are required.' });
    }

    const result = PaymentService.createSubscriptionOrder({
      user,
      planId,
      billingCycle: billingCycle === 'YEARLY' ? 'YEARLY' : 'MONTHLY',
      provider: provider || 'SANDBOX'
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/subscription/verify-payment', authenticate, rateLimit({ max: 20, windowMs: 60000 }), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { paymentId, gatewayPaymentId, gatewayOrderId, signature, provider } = req.body;

    if (!paymentId) {
      return res.status(400).json({ success: false, error: 'Payment ID is required.' });
    }

    const result = PaymentService.processPaymentVerification({
      paymentId,
      gatewayPaymentId: gatewayPaymentId || `pay_verified_${Date.now()}`,
      gatewayOrderId,
      signature,
      provider: provider || 'SANDBOX'
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/subscription/payments-history', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const payments = db.payments.filter(p => p.user_id === user.id);
  return res.json({ success: true, payments });
});

// ==========================================
// 4. TELEGRAM BOT MANAGEMENT ROUTES
// ==========================================

apiRouter.get('/bots', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const isSuperAdmin = user.role === 'SUPER ADMIN' || user.role === 'ADMIN';
  const bots = isSuperAdmin ? db.telegram_bots : db.telegram_bots.filter(b => b.owner_id === user.id);

  // Return masked bots (NEVER expose the encrypted or raw token)
  const safeBots = bots.map(b => {
    const settings = db.bot_settings.find(s => s.bot_id === b.id);
    const productCount = db.products.filter(p => p.bot_id === b.id).length;
    const customerCount = db.customers.filter(c => c.bot_id === b.id).length;
    return {
      id: b.id,
      owner_id: b.owner_id,
      bot_id: b.bot_id,
      username: b.username,
      first_name: b.first_name,
      status: b.status,
      is_active: b.is_active,
      error_message: b.error_message,
      settings: settings || null,
      productCount,
      customerCount,
      created_at: b.created_at
    };
  });

  return res.json({ success: true, bots: safeBots });
});

apiRouter.post('/bots/connect', authenticate, requireActiveSubscription, rateLimit({ max: 10, windowMs: 60000 }), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { token, display_name, support_username } = req.body;
    const user = req.user!;

    if (!token || typeof token !== 'string') {
      return res.status(400).json({ success: false, error: 'Telegram Bot Token is required.' });
    }

    const cleanToken = token.trim();

    // Check user's bot quota based on subscription plan
    const sub = req.subscription;
    const plan = sub ? db.subscription_plans.find(p => p.id === sub.plan_id) : null;
    const maxBots = plan?.max_bots || 1;
    const currentBots = db.telegram_bots.filter(b => b.owner_id === user.id).length;

    if (currentBots >= maxBots) {
      return res.status(403).json({
        success: false,
        error: `Your subscription plan (${plan?.name || 'Starter'}) allows a maximum of ${maxBots} bot(s). Please upgrade to add more.`
      });
    }

    // Verify token with Telegram getMe API (or sample developer mock if token contains sample keyword)
    let botInfo: { id: number; username: string; first_name: string } | undefined;

    if (cleanToken.toLowerCase().includes('demo') || cleanToken.toLowerCase().includes('sample')) {
      botInfo = {
        id: Math.floor(Math.random() * 900000000 + 100000000),
        username: `StoreBot_${Math.floor(Math.random() * 9000 + 1000)}`,
        first_name: display_name || 'My Telegram Store'
      };
    } else {
      const verifyRes = await TelegramService.verifyBotToken(cleanToken);
      if (!verifyRes.ok || !verifyRes.bot) {
        return res.status(400).json({
          success: false,
          error: verifyRes.error || 'Failed to verify bot token with Telegram Bot API. Please check your token from @BotFather.'
        });
      }
      botInfo = verifyRes.bot;
    }

    // Check duplicate bot_id
    const existingBot = db.telegram_bots.find(b => b.bot_id === String(botInfo!.id));
    if (existingBot && existingBot.owner_id !== user.id) {
      return res.status(400).json({
        success: false,
        error: 'This Telegram bot is already connected by another tenant account.'
      });
    }

    const botId = existingBot ? existingBot.id : `bot-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const nowStr = new Date().toISOString();

    const encryptedToken = CryptoService.encrypt(cleanToken);

    if (existingBot) {
      existingBot.bot_token_encrypted = encryptedToken;
      existingBot.first_name = botInfo.first_name;
      existingBot.username = botInfo.username;
      existingBot.status = 'CONNECTED';
      existingBot.updated_at = nowStr;
    } else {
      const newBot: TelegramBot = {
        id: botId,
        owner_id: user.id,
        bot_token_encrypted: encryptedToken,
        bot_id: String(botInfo.id),
        username: botInfo.username,
        first_name: botInfo.first_name,
        can_join_groups: true,
        can_read_all_group_messages: false,
        supports_inline_queries: true,
        is_active: true,
        status: 'CONNECTED',
        created_at: nowStr,
        updated_at: nowStr
      };
      db.telegram_bots.push(newBot);

      // Create initial Bot Settings
      db.bot_settings.push({
        id: `set-${botId}`,
        bot_id: botId,
        owner_id: user.id,
        display_name: display_name || botInfo.first_name,
        description: 'Instant Automated Telegram Digital Store',
        support_username: support_username || '',
        currency: 'INR',
        timezone: 'UTC',
        start_text: `👋 Welcome to *${display_name || botInfo.first_name}*!\n\nBrowse all digital products and activate instant automated delivery below.`,
        start_banner_url: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=1000&q=80',
        promo_message: '✨ Instant 24/7 delivery on all digital products.',
        auto_delivery: true,
        notify_admin_on_order: true,
        created_at: nowStr,
        updated_at: nowStr
      });

      // Seed standard interactive buttons
      db.bot_buttons.push(
        { id: `btn-${Date.now()}-1`, bot_id: botId, owner_id: user.id, label: '🛍️ Browse Products', button_type: 'CALLBACK', target_value: 'VIEW_PRODUCTS', row_order: 0, col_order: 0, created_at: nowStr },
        { id: `btn-${Date.now()}-2`, bot_id: botId, owner_id: user.id, label: '📂 Categories', button_type: 'CATEGORY', target_value: 'ALL_CATEGORIES', row_order: 0, col_order: 1, created_at: nowStr },
        { id: `btn-${Date.now()}-3`, bot_id: botId, owner_id: user.id, label: '💳 My Balance / Wallet', button_type: 'BALANCE', target_value: 'MY_BALANCE', row_order: 1, col_order: 0, created_at: nowStr },
        { id: `btn-${Date.now()}-4`, bot_id: botId, owner_id: user.id, label: '🎁 Promo Coupons', button_type: 'CALLBACK', target_value: 'VIEW_COUPONS', row_order: 1, col_order: 1, created_at: nowStr }
      );
    }

    // Set Webhook if APP_URL is configured
    if (process.env.APP_URL && !cleanToken.includes('demo') && !cleanToken.includes('sample')) {
      const webhookUrl = `${process.env.APP_URL}/api/telegram/webhook/${botId}`;
      TelegramService.setWebhook(cleanToken, webhookUrl).catch(e => console.error('Webhook registration notice:', e));
    }

    logAudit({
      userId: user.id,
      action: 'BOT_CONNECTED',
      resourceType: 'TELEGRAM_BOT',
      resourceId: botId,
      metadata: { username: botInfo.username, botId: botInfo.id },
      req
    });

    db.saveImmediately();

    return res.json({
      success: true,
      bot: {
        id: botId,
        username: botInfo.username,
        first_name: botInfo.first_name,
        bot_id: String(botInfo.id),
        status: 'CONNECTED'
      }
    });
  } catch (err: any) {
    console.error('Bot connect error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/bots/:id/test', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);

    if (!bot) return res.status(404).json({ success: false, error: 'Bot not found.' });
    if (!assertOwnership(user, bot.owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

    const rawToken = CryptoService.decrypt(bot.bot_token_encrypted);
    if (!rawToken) {
      return res.status(400).json({ success: false, error: 'Decryption failed for bot token.' });
    }

    if (rawToken.includes('demo') || rawToken.includes('sample') || rawToken.includes('Sample')) {
      bot.status = 'CONNECTED';
      db.save();
      return res.json({ success: true, message: `Bot @${bot.username} connection is active and responding.` });
    }

    const testRes = await TelegramService.verifyBotToken(rawToken);
    if (testRes.ok) {
      bot.status = 'CONNECTED';
      bot.error_message = undefined;
      db.save();
      return res.json({ success: true, message: `Bot @${bot.username} is connected and healthy.` });
    } else {
      bot.status = 'ERROR';
      bot.error_message = testRes.error;
      db.save();
      return res.status(400).json({ success: false, error: testRes.error || 'Telegram verification failed.' });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/bots/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const botIndex = db.telegram_bots.findIndex(b => b.id === id);

    if (botIndex === -1) return res.status(404).json({ success: false, error: 'Bot not found.' });
    const bot = db.telegram_bots[botIndex];
    if (!assertOwnership(user, bot.owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

    // Clean up associated settings and buttons
    db.telegram_bots.splice(botIndex, 1);
    const settingsIdx = db.bot_settings.findIndex(s => s.bot_id === id);
    if (settingsIdx !== -1) db.bot_settings.splice(settingsIdx, 1);

    const remainingBtns = db.bot_buttons.filter(b => b.bot_id !== id);
    db.bot_buttons = remainingBtns;

    logAudit({
      userId: user.id,
      action: 'BOT_DELETED',
      resourceType: 'TELEGRAM_BOT',
      resourceId: id,
      req
    });

    db.saveImmediately();
    return res.json({ success: true, message: 'Bot disconnected and removed.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Editor Settings
apiRouter.get('/bots/:id/settings', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const bot = db.telegram_bots.find(b => b.id === id);
  if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

  const settings = db.bot_settings.find(s => s.bot_id === id);
  const buttons = db.bot_buttons
    .filter(b => b.bot_id === id)
    .sort((a, b) => a.row_order - b.row_order || a.col_order - b.col_order);
  const faqs = db.bot_faqs.filter(f => f.bot_id === id).sort((a, b) => a.order - b.order);
  const paymentConfig = db.bot_payment_configs.find(p => p.bot_id === id);

  return res.json({ success: true, settings: settings || null, buttons, faqs, paymentConfig: paymentConfig || null });
});

apiRouter.put('/bots/:id/settings', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    const {
      display_name,
      description,
      support_username,
      support_url,
      support_message,
      currency,
      timezone,
      start_text,
      start_banner_url,
      start_video_url,
      promo_message,
      business_hours,
      auto_delivery,
      notify_admin_on_order
    } = req.body;

    let settings = db.bot_settings.find(s => s.bot_id === id);
    const nowStr = new Date().toISOString();

    if (!settings) {
      settings = {
        id: `set-${id}`,
        bot_id: id,
        owner_id: user.id,
        display_name: display_name || bot.first_name,
        description: description || '',
        support_username: support_username || '',
        support_url: support_url || '',
        support_message: support_message || '',
        currency: currency || 'INR',
        timezone: timezone || 'UTC',
        start_text: start_text || '',
        start_banner_url,
        start_video_url,
        promo_message,
        business_hours,
        auto_delivery: auto_delivery ?? true,
        notify_admin_on_order: notify_admin_on_order ?? true,
        created_at: nowStr,
        updated_at: nowStr
      };
      db.bot_settings.push(settings);
    } else {
      if (display_name !== undefined) settings.display_name = display_name;
      if (description !== undefined) settings.description = description;
      if (support_username !== undefined) settings.support_username = support_username;
      if (support_url !== undefined) settings.support_url = support_url;
      if (support_message !== undefined) settings.support_message = support_message;
      if (currency !== undefined) settings.currency = currency;
      if (timezone !== undefined) settings.timezone = timezone;
      if (start_text !== undefined) settings.start_text = start_text;
      if (start_banner_url !== undefined) settings.start_banner_url = start_banner_url;
      if (start_video_url !== undefined) settings.start_video_url = start_video_url;
      if (promo_message !== undefined) settings.promo_message = promo_message;
      if (business_hours !== undefined) settings.business_hours = business_hours;
      if (auto_delivery !== undefined) settings.auto_delivery = auto_delivery;
      if (notify_admin_on_order !== undefined) settings.notify_admin_on_order = notify_admin_on_order;
      settings.updated_at = nowStr;
    }

    logAudit({
      userId: user.id,
      action: 'BOT_SETTINGS_UPDATED',
      resourceType: 'BOT_SETTINGS',
      resourceId: id,
      req
    });

    db.saveImmediately();
    return res.json({ success: true, settings });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Submenus / Menus CRUD (Nested Multi-level Navigation)
apiRouter.get('/bots/:id/menus', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    let menus = db.bot_menus.filter(m => m.bot_id === id);
    if (menus.length === 0) {
      // Auto create the default 'main' menu if none exist
      const defaultMainMenu: BotMenu = {
        id: `menu-main-${id}`,
        bot_id: id,
        owner_id: user.id,
        title: 'Main Menu',
        slug: 'main',
        message_text: 'Welcome to our store! Browse categories and products below.',
        auto_back_button: false,
        auto_home_button: false,
        columns_per_row: 2,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      db.bot_menus.push(defaultMainMenu);
      db.saveImmediately();
      menus = [defaultMainMenu];
    }

    return res.json({ success: true, menus });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/bots/:id/menus', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    const { title, slug, parent_menu_id, message_text, banner_url, video_url, auto_back_button, auto_home_button, columns_per_row } = req.body;

    if (!title) {
      return res.status(400).json({ success: false, error: 'Menu title is required.' });
    }

    const cleanSlug = (slug || title.toLowerCase().replace(/[^a-z0-9_-]/g, '-')).trim();
    const nowStr = new Date().toISOString();

    const newMenu: BotMenu = {
      id: `menu-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      bot_id: id,
      owner_id: user.id,
      title: String(title).trim(),
      slug: cleanSlug,
      parent_menu_id: parent_menu_id || undefined,
      message_text: message_text || `📂 *${title}*\nSelect an option below:`,
      banner_url: banner_url || undefined,
      video_url: video_url || undefined,
      auto_back_button: auto_back_button !== false,
      auto_home_button: auto_home_button !== false,
      columns_per_row: Number(columns_per_row) || 2,
      created_at: nowStr,
      updated_at: nowStr
    };

    db.bot_menus.push(newMenu);
    db.saveImmediately();

    return res.json({ success: true, menu: newMenu });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.put('/bots/:id/menus/:menuId', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id, menuId } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    const menu = db.bot_menus.find(m => m.id === menuId && m.bot_id === id);
    if (!menu) {
      return res.status(404).json({ success: false, error: 'Menu not found.' });
    }

    const { title, slug, parent_menu_id, message_text, banner_url, video_url, auto_back_button, auto_home_button, columns_per_row } = req.body;

    if (title !== undefined) menu.title = String(title).trim();
    if (slug !== undefined) menu.slug = String(slug).trim();
    if (parent_menu_id !== undefined) menu.parent_menu_id = parent_menu_id || undefined;
    if (message_text !== undefined) menu.message_text = message_text;
    if (banner_url !== undefined) menu.banner_url = banner_url;
    if (video_url !== undefined) menu.video_url = video_url;
    if (auto_back_button !== undefined) menu.auto_back_button = !!auto_back_button;
    if (auto_home_button !== undefined) menu.auto_home_button = !!auto_home_button;
    if (columns_per_row !== undefined) menu.columns_per_row = Number(columns_per_row) || 2;
    menu.updated_at = new Date().toISOString();

    db.saveImmediately();
    return res.json({ success: true, menu });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/bots/:id/menus/:menuId', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id, menuId } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    // Do not delete main menu
    const menu = db.bot_menus.find(m => m.id === menuId && m.bot_id === id);
    if (menu?.slug === 'main') {
      return res.status(400).json({ success: false, error: 'Cannot delete default Main Menu.' });
    }

    db.bot_menus = db.bot_menus.filter(m => m.id !== menuId || m.bot_id !== id);
    // Remove or reassign buttons attached to this menu
    db.bot_buttons = db.bot_buttons.filter(b => b.menu_id !== menuId && b.target_value !== menuId);
    db.saveImmediately();

    return res.json({ success: true, message: 'Menu deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bulk Save Menus
apiRouter.put('/bots/:id/menus', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { menus } = req.body;

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    if (!Array.isArray(menus)) {
      return res.status(400).json({ success: false, error: 'Menus must be an array.' });
    }

    db.bot_menus = db.bot_menus.filter(m => m.bot_id !== id);
    const nowStr = new Date().toISOString();

    const newMenus: BotMenu[] = menus.map((m: any, idx: number) => ({
      id: m.id || `menu-${Date.now()}-${idx}`,
      bot_id: id,
      owner_id: user.id,
      title: String(m.title || 'Submenu').trim(),
      slug: String(m.slug || `menu-${idx}`).trim(),
      parent_menu_id: m.parent_menu_id || undefined,
      message_text: m.message_text || 'Select an option below:',
      banner_url: m.banner_url || undefined,
      video_url: m.video_url || undefined,
      auto_back_button: m.auto_back_button !== false,
      auto_home_button: m.auto_home_button !== false,
      columns_per_row: Number(m.columns_per_row) || 2,
      created_at: m.created_at || nowStr,
      updated_at: nowStr
    }));

    db.bot_menus.push(...newMenus);
    db.saveImmediately();

    return res.json({ success: true, menus: newMenus });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Inline Buttons Builder (Multi-level aware)
apiRouter.post('/bots/:id/buttons', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { buttons } = req.body; // Array of buttons

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    if (!Array.isArray(buttons)) {
      return res.status(400).json({ success: false, error: 'Buttons must be an array.' });
    }

    // Remove existing buttons for this bot
    db.bot_buttons = db.bot_buttons.filter(b => b.bot_id !== id);

    const nowStr = new Date().toISOString();
    const newButtons: BotButton[] = buttons.map((btn: any, idx: number) => ({
      id: btn.id || `btn-${Date.now()}-${idx}`,
      bot_id: id,
      menu_id: btn.menu_id || 'main',
      owner_id: user.id,
      label: btn.label || 'Button',
      emoji: btn.emoji || undefined,
      button_type: btn.button_type || 'CALLBACK',
      target_value: btn.target_value || 'DEFAULT',
      target_package_id: btn.target_package_id || undefined,
      row_order: Number(btn.row_order) || 0,
      col_order: Number(btn.col_order) || 0,
      created_at: nowStr
    }));

    db.bot_buttons.push(...newButtons);
    db.saveImmediately();

    return res.json({ success: true, buttons: newButtons });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Atomic Full Save Endpoint (Settings, Menus, Buttons, FAQs, Payment Config)
apiRouter.post('/bots/:id/full-save', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { settings, menus, buttons, faqs, paymentConfig } = req.body;

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    const nowStr = new Date().toISOString();

    // 1. Save Settings
    if (settings) {
      let currentSettings = db.bot_settings.find(s => s.bot_id === id);
      if (!currentSettings) {
        currentSettings = {
          id: `bot-set-${id}`,
          bot_id: id,
          owner_id: user.id,
          display_name: settings.display_name || bot.first_name,
          description: settings.description || '',
          support_username: settings.support_username || '',
          support_url: settings.support_url || '',
          support_message: settings.support_message || '',
          currency: settings.currency || 'INR',
          timezone: settings.timezone || 'UTC',
          start_text: settings.start_text || 'Welcome to our store! Click below to browse.',
          start_banner_url: settings.start_banner_url || undefined,
          start_video_url: settings.start_video_url || undefined,
          promo_message: settings.promo_message || undefined,
          business_hours: settings.business_hours || undefined,
          auto_delivery: settings.auto_delivery ?? true,
          notify_admin_on_order: settings.notify_admin_on_order ?? true,
          created_at: nowStr,
          updated_at: nowStr
        };
        db.bot_settings.push(currentSettings);
      } else {
        Object.assign(currentSettings, {
          ...settings,
          updated_at: nowStr
        });
      }
    }

    // 2. Save Menus
    if (Array.isArray(menus)) {
      db.bot_menus = db.bot_menus.filter(m => m.bot_id !== id);
      const newMenus: BotMenu[] = menus.map((m: any, idx: number) => ({
        id: m.id || `menu-${Date.now()}-${idx}`,
        bot_id: id,
        owner_id: user.id,
        title: String(m.title || 'Menu').trim(),
        slug: String(m.slug || (idx === 0 ? 'main' : `menu-${idx}`)).trim(),
        parent_menu_id: m.parent_menu_id || undefined,
        message_text: m.message_text || 'Select an option below:',
        banner_url: m.banner_url || undefined,
        video_url: m.video_url || undefined,
        auto_back_button: m.auto_back_button !== false,
        auto_home_button: m.auto_home_button !== false,
        columns_per_row: Number(m.columns_per_row) || 2,
        created_at: m.created_at || nowStr,
        updated_at: nowStr
      }));
      db.bot_menus.push(...newMenus);
    }

    // 3. Save Buttons
    if (Array.isArray(buttons)) {
      db.bot_buttons = db.bot_buttons.filter(b => b.bot_id !== id);
      const newButtons: BotButton[] = buttons.map((btn: any, idx: number) => ({
        id: btn.id || `btn-${Date.now()}-${idx}`,
        bot_id: id,
        menu_id: btn.menu_id || 'main',
        owner_id: user.id,
        label: btn.label || 'Button',
        emoji: btn.emoji || undefined,
        button_type: btn.button_type || 'CALLBACK',
        target_value: btn.target_value || 'DEFAULT',
        target_package_id: btn.target_package_id || undefined,
        row_order: Number(btn.row_order) || 0,
        col_order: Number(btn.col_order) || 0,
        created_at: nowStr
      }));
      db.bot_buttons.push(...newButtons);
    }

    // 4. Save FAQs
    if (Array.isArray(faqs)) {
      db.bot_faqs = db.bot_faqs.filter(f => f.bot_id !== id);
      const newFaqs: BotFaq[] = faqs.map((f: any, idx: number) => ({
        id: f.id || `faq-${Date.now()}-${idx}`,
        bot_id: id,
        owner_id: user.id,
        question: String(f.question || '').trim(),
        answer: String(f.answer || '').trim(),
        order: Number(f.order) || idx,
        created_at: nowStr
      }));
      db.bot_faqs.push(...newFaqs);
    }

    // 5. Save Payment Config
    if (paymentConfig) {
      let currentPayConfig = db.bot_payment_configs.find(p => p.bot_id === id);
      if (!currentPayConfig) {
        currentPayConfig = {
          id: `pay-cfg-${id}`,
          bot_id: id,
          owner_id: user.id,
          enable_sandbox: paymentConfig.enable_sandbox ?? true,
          enable_razorpay: !!paymentConfig.enable_razorpay,
          enable_cashfree: !!paymentConfig.enable_cashfree,
          enable_phonepe: !!paymentConfig.enable_phonepe,
          enable_stripe: !!paymentConfig.enable_stripe,
          enable_manual_upi: paymentConfig.enable_manual_upi ?? true,
          upi_id: paymentConfig.upi_id || '',
          upi_name: paymentConfig.upi_name || '',
          business_name: paymentConfig.business_name || '',
          default_amount: Number(paymentConfig.default_amount) || undefined,
          enable_dynamic_qr: paymentConfig.enable_dynamic_qr ?? true,
          qr_data_scheme: paymentConfig.qr_data_scheme || '',
          manual_instructions: paymentConfig.manual_instructions || '',
          qr_image_url: paymentConfig.qr_image_url || '',
          bank_account_number: paymentConfig.bank_account_number || '',
          bank_ifsc: paymentConfig.bank_ifsc || '',
          bank_name: paymentConfig.bank_name || '',
          razorpay_key_id: paymentConfig.razorpay_key_id || '',
          stripe_public_key: paymentConfig.stripe_public_key || '',
          created_at: nowStr,
          updated_at: nowStr
        };
        db.bot_payment_configs.push(currentPayConfig);
      } else {
        Object.assign(currentPayConfig, {
          ...paymentConfig,
          updated_at: nowStr
        });
      }
    }

    logAudit({
      userId: user.id,
      action: 'BOT_FULL_SAVE',
      resourceType: 'TELEGRAM_BOT',
      resourceId: id,
      req
    });

    db.saveImmediately();

    return res.json({
      success: true,
      message: 'All bot settings, navigation tree, submenus, buttons, FAQs, and payment gateways saved successfully!'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Deployment & Telegram Synchronization
apiRouter.post('/bots/:id/deploy', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { versionLabel } = req.body || {};

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(404).json({ success: false, error: 'Bot not found.' });
    }

    const settings = db.bot_settings.find(s => s.bot_id === id);
    const menus = db.bot_menus.filter(m => m.bot_id === id);
    const buttons = db.bot_buttons.filter(b => b.bot_id === id);
    const faqs = db.bot_faqs.filter(f => f.bot_id === id);

    // Create a Version Snapshot for instant rollback
    const existingVersions = db.bot_versions.filter(v => v.bot_id === id);
    const versionNumber = existingVersions.length + 1;
    const newVersion: BotVersion = {
      id: `ver-${id}-${versionNumber}-${Date.now()}`,
      bot_id: id,
      owner_id: user.id,
      version_number: versionNumber,
      label: versionLabel || `Version ${versionNumber} (${new Date().toLocaleDateString()})`,
      settings: JSON.parse(JSON.stringify(settings || {})),
      menus: JSON.parse(JSON.stringify(menus || [])),
      buttons: JSON.parse(JSON.stringify(buttons || [])),
      faqs: JSON.parse(JSON.stringify(faqs || [])),
      created_at: new Date().toISOString()
    };
    db.bot_versions.unshift(newVersion);

    // Synchronize with Telegram Bot API
    const syncDetails = await TelegramService.syncBotProfileWithTelegram(bot);

    logAudit({
      userId: user.id,
      action: 'BOT_DEPLOYED',
      resourceType: 'TELEGRAM_BOT',
      resourceId: id,
      metadata: { versionNumber, syncDetails },
      req
    });

    db.saveImmediately();

    return res.json({
      success: true,
      deployed: true,
      message: 'Bot settings synchronized and deployed successfully!',
      version: newVersion,
      syncDetails
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Reconnect Bot Token
apiRouter.post('/bots/:id/reconnect', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { token } = req.body;

    if (!token) return res.status(400).json({ success: false, error: 'Telegram Bot token is required.' });

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    const verification = await TelegramService.verifyBotToken(token);
    if (!verification.ok || !verification.bot) {
      return res.status(400).json({ success: false, error: verification.error || 'Token verification failed.' });
    }

    bot.bot_token_encrypted = CryptoService.encrypt(token);
    bot.first_name = verification.bot.first_name;
    bot.username = verification.bot.username;
    bot.status = 'CONNECTED';
    bot.error_message = undefined;
    bot.updated_at = new Date().toISOString();

    await TelegramService.syncBotProfileWithTelegram(bot);
    db.saveImmediately();

    return res.json({ success: true, bot });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot FAQs
apiRouter.get('/bots/:id/faqs', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const bot = db.telegram_bots.find(b => b.id === id);
  if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

  const faqs = db.bot_faqs.filter(f => f.bot_id === id).sort((a, b) => a.order - b.order);
  return res.json({ success: true, faqs });
});

apiRouter.put('/bots/:id/faqs', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { faqs } = req.body;

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    if (!Array.isArray(faqs)) return res.status(400).json({ success: false, error: 'Faqs must be an array.' });

    db.bot_faqs = db.bot_faqs.filter(f => f.bot_id !== id);

    const nowStr = new Date().toISOString();
    const newFaqs: BotFaq[] = faqs.map((f: any, idx: number) => ({
      id: f.id || `faq-${Date.now()}-${idx}`,
      bot_id: id,
      owner_id: user.id,
      question: String(f.question || '').trim(),
      answer: String(f.answer || '').trim(),
      order: Number(f.order) || idx,
      created_at: nowStr
    }));

    db.bot_faqs.push(...newFaqs);
    db.saveImmediately();

    return res.json({ success: true, faqs: newFaqs });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Revisions / Version History
apiRouter.get('/bots/:id/versions', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const bot = db.telegram_bots.find(b => b.id === id);
  if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

  const versions = db.bot_versions.filter(v => v.bot_id === id).sort((a, b) => b.version_number - a.version_number);
  return res.json({ success: true, versions });
});

apiRouter.post('/bots/:id/versions/:versionId/restore', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id, versionId } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    const version = db.bot_versions.find(v => v.id === versionId && v.bot_id === id);
    if (!version) return res.status(404).json({ success: false, error: 'Version not found.' });

    // Restore settings
    let settings = db.bot_settings.find(s => s.bot_id === id);
    if (settings && version.settings) {
      Object.assign(settings, version.settings, { updated_at: new Date().toISOString() });
    }

    // Restore buttons
    if (version.buttons) {
      db.bot_buttons = db.bot_buttons.filter(b => b.bot_id !== id);
      db.bot_buttons.push(...version.buttons);
    }

    // Restore FAQs
    if (version.faqs) {
      db.bot_faqs = db.bot_faqs.filter(f => f.bot_id !== id);
      db.bot_faqs.push(...version.faqs);
    }

    db.saveImmediately();

    return res.json({
      success: true,
      message: `Restored to version ${version.version_number} (${version.label})`,
      settings,
      buttons: db.bot_buttons.filter(b => b.bot_id === id)
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bot Payment Configuration & QR
apiRouter.get('/bots/:id/payment-config', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const bot = db.telegram_bots.find(b => b.id === id);
  if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

  let config = db.bot_payment_configs.find(p => p.bot_id === id);
  if (!config) {
    config = {
      id: `paycfg-${id}`,
      bot_id: id,
      owner_id: user.id,
      enable_sandbox: true,
      enable_razorpay: false,
      enable_cashfree: false,
      enable_phonepe: false,
      enable_stripe: false,
      enable_manual_upi: true,
      upi_id: 'merchant@upi',
      upi_name: 'Merchant Pay',
      manual_instructions: 'Please transfer the exact amount and submit your payment screenshot for instant order verification.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    db.bot_payment_configs.push(config);
    db.save();
  }

  return res.json({ success: true, config });
});

apiRouter.put('/bots/:id/payment-config', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    let config = db.bot_payment_configs.find(p => p.bot_id === id);
    const nowStr = new Date().toISOString();

    if (!config) {
      config = {
        id: `paycfg-${id}`,
        bot_id: id,
        owner_id: user.id,
        ...req.body,
        created_at: nowStr,
        updated_at: nowStr
      };
      db.bot_payment_configs.push(config);
    } else {
      Object.assign(config, req.body, { updated_at: nowStr });
    }

    db.saveImmediately();
    return res.json({ success: true, config });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Media Manager
apiRouter.get('/media', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { bot_id } = req.query;
  let items = db.media_items.filter(m => m.owner_id === user.id);
  if (bot_id) items = items.filter(m => m.bot_id === String(bot_id));
  return res.json({ success: true, items });
});

apiRouter.post('/media/upload', authenticate, upload.single('file'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const file = req.file;
    const { bot_id, media_type } = req.body;

    if (!file) return res.status(400).json({ success: false, error: 'No file uploaded.' });

    const fileUrl = `/api/media/file/${file.filename}`;
    const mediaItem: MediaItem = {
      id: `med-${Date.now()}`,
      owner_id: user.id,
      bot_id: bot_id || undefined,
      media_type: media_type || (file.mimetype.startsWith('image/') ? 'IMAGE' : file.mimetype.startsWith('video/') ? 'VIDEO' : 'DOCUMENT'),
      original_name: file.originalname,
      stored_name: file.filename,
      url: fileUrl,
      file_size: file.size,
      mime_type: file.mimetype,
      created_at: new Date().toISOString()
    };

    db.media_items.unshift(mediaItem);
    db.saveImmediately();

    return res.json({ success: true, item: mediaItem });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/media/file/:filename', (req: Request, res: Response) => {
  const { filename } = req.params;
  // Security path check
  const safeFilename = path.basename(filename);
  const filePath = path.join(uploadDir, safeFilename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found');
  }

  return res.sendFile(filePath);
});

apiRouter.delete('/media/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const index = db.media_items.findIndex(m => m.id === id && m.owner_id === user.id);
    if (index === -1) return res.status(404).json({ success: false, error: 'Media not found.' });

    const item = db.media_items[index];
    const filePath = path.join(uploadDir, item.stored_name);
    if (fs.existsSync(filePath)) {
      try { fs.unlinkSync(filePath); } catch {}
    }

    db.media_items.splice(index, 1);
    db.saveImmediately();

    return res.json({ success: true, message: 'Media deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Payment Proofs Review (Manual UPI Verification)
apiRouter.get('/payment-proofs', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { bot_id, status } = req.query;
  let proofs = db.payment_proofs.filter(p => p.owner_id === user.id);
  if (bot_id) proofs = proofs.filter(p => p.bot_id === String(bot_id));
  if (status) proofs = proofs.filter(p => p.status === String(status));
  return res.json({ success: true, proofs });
});

apiRouter.post('/payment-proofs/upload', authenticate, upload.single('file'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const file = req.file;
    const { order_id, customer_note } = req.body;

    if (!file) return res.status(400).json({ success: false, error: 'Please upload a proof screenshot.' });
    if (!order_id) return res.status(400).json({ success: false, error: 'Order ID is required.' });

    const order = db.orders.find(o => o.id === order_id);
    if (!order) return res.status(404).json({ success: false, error: 'Order not found.' });

    const proofUrl = `/api/media/file/${file.filename}`;
    const proof: PaymentProof = {
      id: `proof-${Date.now()}`,
      order_id,
      customer_id: order.customer_id,
      bot_id: order.bot_id,
      owner_id: order.owner_id,
      proof_image_url: proofUrl,
      amount: order.total_amount,
      customer_note: customer_note || undefined,
      status: 'PENDING',
      created_at: new Date().toISOString()
    };

    db.payment_proofs.unshift(proof);
    order.status = 'PENDING';
    db.saveImmediately();

    return res.json({ success: true, proof });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/payment-proofs/:id/review', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { action, notes } = req.body; // 'APPROVE' or 'REJECT'

    const proof = db.payment_proofs.find(p => p.id === id && p.owner_id === user.id);
    if (!proof) return res.status(404).json({ success: false, error: 'Proof not found.' });

    const order = db.orders.find(o => o.id === proof.order_id);
    const nowStr = new Date().toISOString();

    if (action === 'APPROVE') {
      proof.status = 'APPROVED';
      proof.reviewed_by = user.id;
      proof.reviewed_at = nowStr;

      if (order) {
        order.status = 'DELIVERED';
        order.payment_id = `proof_appr_${id}`;
        order.updated_at = nowStr;

        // Fulfill digital delivery if not already done
        const product = db.products.find(p => p.id === order.product_id);
        if (product && (product.delivery_type === 'LICENSE_KEY' || product.delivery_type === 'SERIAL_KEY')) {
          const availableKey = db.license_keys.find(k => k.product_id === product.id && !k.is_redeemed);
          if (availableKey) {
            availableKey.is_redeemed = true;
            availableKey.redeemed_by_customer_id = order.customer_id;
            availableKey.redeemed_at = nowStr;
            availableKey.order_id = order.id;
            order.delivered_content = `🔑 *Your License Key:*\n\`${availableKey.license_key}\``;
            product.stock_count = Math.max(0, product.stock_count - 1);
          }
        }
      }
    } else {
      proof.status = 'REJECTED';
      proof.reviewed_by = user.id;
      proof.reviewed_at = nowStr;
      if (order) {
        order.status = 'CANCELLED';
        order.updated_at = nowStr;
      }
    }

    db.saveImmediately();
    return res.json({ success: true, proof, order });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Interactive Live Bot Simulator Route (Live test in UI)
apiRouter.post('/bots/:id/simulate', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { text, callback_data, customer_id, customer_name } = req.body;

    const bot = db.telegram_bots.find(b => b.id === id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(404).json({ success: false, error: 'Bot not found.' });

    const simTgUser = {
      id: Number(customer_id) || 99881122,
      is_bot: false,
      first_name: customer_name || 'Live Tester',
      username: 'tester_user'
    };

    const update: any = {};
    if (callback_data) {
      update.callback_query = {
        id: `cq-${Date.now()}`,
        from: simTgUser,
        data: callback_data,
        message: {
          message_id: 100,
          chat: { id: simTgUser.id, type: 'private' },
          date: Math.floor(Date.now() / 1000)
        }
      };
    } else {
      update.message = {
        message_id: 100,
        from: simTgUser,
        chat: { id: simTgUser.id, type: 'private' },
        date: Math.floor(Date.now() / 1000),
        text: text || '/start'
      };
    }

    const result = await TelegramService.processUpdate(bot, update, true);
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 5. PRODUCTS & DIGITAL DELIVERY CRUD
// ==========================================

apiRouter.get('/products', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const isSuperAdmin = user.role === 'SUPER ADMIN' || user.role === 'ADMIN';
    const { bot_id, search, category_id } = req.query;

    let products = isSuperAdmin ? db.products : db.products.filter(p => p.owner_id === user.id);

    if (bot_id) {
      products = products.filter(p => p.bot_id === String(bot_id));
    }
    if (category_id) {
      products = products.filter(p => p.category_id === String(category_id));
    }
    if (search) {
      const q = String(search).toLowerCase();
      products = products.filter(p => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    }

    const result = products.map(p => {
      const category = db.product_categories.find(c => c.id === p.category_id);
      const keysAvailable = db.license_keys.filter(k => k.product_id === p.id && !k.is_redeemed).length;
      const fileRecord = db.digital_files.find(f => f.product_id === p.id);
      const packages = db.product_packages
        .filter(pkg => pkg.product_id === p.id && pkg.is_active)
        .sort((a, b) => a.order_index - b.order_index);
      return {
        ...p,
        category_name: category?.name || 'General',
        keys_available: keysAvailable,
        file_name: fileRecord?.original_filename || null,
        packages
      };
    });

    return res.json({ success: true, products: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/products', authenticate, requireActiveSubscription, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const {
      bot_id,
      category_id,
      name,
      description,
      price,
      currency,
      image_url,
      delivery_type,
      custom_message,
      stock_count,
      license_keys, // optional array or bulk string
      packages // optional array of variants/packages
    } = req.body;

    if (!bot_id || !name || price === undefined) {
      return res.status(400).json({ success: false, error: 'Bot ID, Product Name, and Price are required.' });
    }

    const bot = db.telegram_bots.find(b => b.id === bot_id);
    if (!bot || !assertOwnership(user, bot.owner_id)) {
      return res.status(403).json({ success: false, error: 'Forbidden. You do not own this bot.' });
    }

    const nowStr = new Date().toISOString();
    const productId = `prod-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;

    const newProduct: Product = {
      id: productId,
      owner_id: user.id,
      bot_id,
      category_id: category_id || undefined,
      name: String(name).trim(),
      description: description || '',
      price: Number(price),
      currency: currency || 'INR',
      image_url: image_url || undefined,
      delivery_type: delivery_type || 'LICENSE_KEY',
      custom_message: custom_message || undefined,
      is_active: true,
      stock_count: Number(stock_count) || 0,
      created_at: nowStr,
      updated_at: nowStr
    };

    db.products.unshift(newProduct);

    // Save packages if provided
    if (Array.isArray(packages) && packages.length > 0) {
      const newPkgs: ProductPackage[] = packages.map((pkg: any, idx: number) => ({
        id: pkg.id || `pkg-${Date.now()}-${idx}`,
        product_id: productId,
        bot_id,
        owner_id: user.id,
        name: String(pkg.name).trim(),
        duration_days: pkg.duration_days ? Number(pkg.duration_days) : undefined,
        price: Number(pkg.price) || Number(price),
        currency: pkg.currency || currency || 'INR',
        stock_count: pkg.stock_count !== undefined ? Number(pkg.stock_count) : 999,
        delivery_type: pkg.delivery_type || delivery_type || 'LICENSE_KEY',
        custom_message: pkg.custom_message || undefined,
        digital_file_url: pkg.digital_file_url || undefined,
        is_active: pkg.is_active !== false,
        order_index: Number(pkg.order_index) || idx,
        created_at: nowStr,
        updated_at: nowStr
      }));
      db.product_packages.push(...newPkgs);
      newProduct.packages = newPkgs;
    }

    // If license keys provided in payload
    if (license_keys && (delivery_type === 'LICENSE_KEY' || delivery_type === 'SERIAL_KEY')) {
      const keysList: string[] = Array.isArray(license_keys)
        ? license_keys
        : String(license_keys).split('\n').map(k => k.trim()).filter(Boolean);

      for (const k of keysList) {
        db.license_keys.push({
          id: `key-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          owner_id: user.id,
          product_id: productId,
          license_key: k,
          is_redeemed: false,
          created_at: nowStr
        });
      }
      newProduct.stock_count = keysList.length;
    }

    logAudit({
      userId: user.id,
      action: 'PRODUCT_CREATED',
      resourceType: 'PRODUCT',
      resourceId: productId,
      metadata: { name: newProduct.name, price: newProduct.price },
      req
    });

    db.saveImmediately();
    return res.json({ success: true, product: newProduct });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.put('/products/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const product = db.products.find(p => p.id === id);

    if (!product || !assertOwnership(user, product.owner_id)) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }

    const {
      name,
      description,
      price,
      currency,
      category_id,
      image_url,
      delivery_type,
      custom_message,
      is_active,
      stock_count,
      packages
    } = req.body;

    if (name !== undefined) product.name = name;
    if (description !== undefined) product.description = description;
    if (price !== undefined) product.price = Number(price);
    if (currency !== undefined) product.currency = currency;
    if (category_id !== undefined) product.category_id = category_id;
    if (image_url !== undefined) product.image_url = image_url;
    if (delivery_type !== undefined) product.delivery_type = delivery_type;
    if (custom_message !== undefined) product.custom_message = custom_message;
    if (is_active !== undefined) product.is_active = is_active;
    if (stock_count !== undefined) product.stock_count = Number(stock_count);
    product.updated_at = new Date().toISOString();

    // Sync packages if provided
    if (Array.isArray(packages)) {
      db.product_packages = db.product_packages.filter(pkg => pkg.product_id !== id);
      const nowStr = new Date().toISOString();
      const updatedPkgs: ProductPackage[] = packages.map((pkg: any, idx: number) => ({
        id: pkg.id || `pkg-${Date.now()}-${idx}`,
        product_id: id,
        bot_id: product.bot_id,
        owner_id: user.id,
        name: String(pkg.name).trim(),
        duration_days: pkg.duration_days ? Number(pkg.duration_days) : undefined,
        price: Number(pkg.price) || product.price,
        currency: pkg.currency || product.currency,
        stock_count: pkg.stock_count !== undefined ? Number(pkg.stock_count) : 999,
        delivery_type: pkg.delivery_type || product.delivery_type,
        custom_message: pkg.custom_message || undefined,
        digital_file_url: pkg.digital_file_url || undefined,
        is_active: pkg.is_active !== false,
        order_index: Number(pkg.order_index) || idx,
        created_at: pkg.created_at || nowStr,
        updated_at: nowStr
      }));
      db.product_packages.push(...updatedPkgs);
      product.packages = updatedPkgs;
    }

    logAudit({
      userId: user.id,
      action: 'PRODUCT_UPDATED',
      resourceType: 'PRODUCT',
      resourceId: id,
      req
    });

    db.saveImmediately();
    return res.json({ success: true, product });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Product Packages / Variants Endpoints
apiRouter.get('/products/:id/packages', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const product = db.products.find(p => p.id === id);
    if (!product || !assertOwnership(user, product.owner_id)) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }

    const packages = db.product_packages
      .filter(pkg => pkg.product_id === id)
      .sort((a, b) => a.order_index - b.order_index);

    return res.json({ success: true, packages });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/products/:id/packages', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const product = db.products.find(p => p.id === id);
    if (!product || !assertOwnership(user, product.owner_id)) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }

    const { name, duration_days, price, currency, stock_count, delivery_type, custom_message, digital_file_url } = req.body;
    if (!name || price === undefined) {
      return res.status(400).json({ success: false, error: 'Package name and price are required.' });
    }

    const nowStr = new Date().toISOString();
    const existingCount = db.product_packages.filter(p => p.product_id === id).length;

    const newPkg: ProductPackage = {
      id: `pkg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      product_id: id,
      bot_id: product.bot_id,
      owner_id: user.id,
      name: String(name).trim(),
      duration_days: duration_days ? Number(duration_days) : undefined,
      price: Number(price),
      currency: currency || product.currency,
      stock_count: stock_count !== undefined ? Number(stock_count) : 999,
      delivery_type: delivery_type || product.delivery_type,
      custom_message: custom_message || undefined,
      digital_file_url: digital_file_url || undefined,
      is_active: true,
      order_index: existingCount,
      created_at: nowStr,
      updated_at: nowStr
    };

    db.product_packages.push(newPkg);
    db.saveImmediately();

    return res.json({ success: true, package: newPkg });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.put('/products/:id/packages/:pkgId', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id, pkgId } = req.params;
    const user = req.user!;
    const pkg = db.product_packages.find(p => p.id === pkgId && p.product_id === id && p.owner_id === user.id);
    if (!pkg) return res.status(404).json({ success: false, error: 'Package variant not found.' });

    const { name, duration_days, price, currency, stock_count, delivery_type, custom_message, digital_file_url, is_active, order_index } = req.body;

    if (name !== undefined) pkg.name = String(name).trim();
    if (duration_days !== undefined) pkg.duration_days = duration_days ? Number(duration_days) : undefined;
    if (price !== undefined) pkg.price = Number(price);
    if (currency !== undefined) pkg.currency = currency;
    if (stock_count !== undefined) pkg.stock_count = Number(stock_count);
    if (delivery_type !== undefined) pkg.delivery_type = delivery_type;
    if (custom_message !== undefined) pkg.custom_message = custom_message;
    if (digital_file_url !== undefined) pkg.digital_file_url = digital_file_url;
    if (is_active !== undefined) pkg.is_active = !!is_active;
    if (order_index !== undefined) pkg.order_index = Number(order_index);
    pkg.updated_at = new Date().toISOString();

    db.saveImmediately();
    return res.json({ success: true, package: pkg });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/products/:id/packages/:pkgId', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id, pkgId } = req.params;
    const user = req.user!;
    const index = db.product_packages.findIndex(p => p.id === pkgId && p.product_id === id && p.owner_id === user.id);
    if (index === -1) return res.status(404).json({ success: false, error: 'Package not found.' });

    db.product_packages.splice(index, 1);
    db.saveImmediately();
    return res.json({ success: true, message: 'Package deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Dynamic & Static UPI QR Code Generator
apiRouter.post('/payments/generate-qr', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { upi_id, upi_name, business_name, amount, order_id, note, currency } = req.body;

    if (!upi_id) {
      return res.status(400).json({ success: false, error: 'UPI ID (VPA) is required to generate payment QR.' });
    }

    const cleanUpi = String(upi_id).trim();
    const payeeName = (upi_name || business_name || 'Merchant').trim();
    const refNote = (note || order_id || 'Digital Store Purchase').trim();
    const curr = currency || 'INR';
    const amtStr = amount ? Number(amount).toFixed(2) : '';

    // Standardized NPCI UPI URI Specification
    let upiUri = `upi://pay?pa=${encodeURIComponent(cleanUpi)}&pn=${encodeURIComponent(payeeName)}`;
    if (amtStr && Number(amtStr) > 0) {
      upiUri += `&am=${amtStr}&cu=${curr}`;
    }
    if (refNote) {
      upiUri += `&tn=${encodeURIComponent(refNote)}`;
    }

    // High quality QR Code image link (SVG/PNG)
    const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiUri)}`;

    return res.json({
      success: true,
      upiUri,
      qrImageUrl,
      details: {
        upi_id: cleanUpi,
        payee_name: payeeName,
        amount: amtStr ? Number(amtStr) : undefined,
        currency: curr,
        note: refNote
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/products/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const index = db.products.findIndex(p => p.id === id);

    if (index === -1) return res.status(404).json({ success: false, error: 'Product not found.' });
    const product = db.products[index];
    if (!assertOwnership(user, product.owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

    db.products.splice(index, 1);

    // Delete associated keys
    db.license_keys = db.license_keys.filter(k => k.product_id !== id);

    logAudit({
      userId: user.id,
      action: 'PRODUCT_DELETED',
      resourceType: 'PRODUCT',
      resourceId: id,
      req
    });

    db.saveImmediately();
    return res.json({ success: true, message: 'Product deleted.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Bulk License Keys Manager
apiRouter.get('/products/:id/licenses', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const product = db.products.find(p => p.id === id);
  if (!product || !assertOwnership(user, product.owner_id)) return res.status(404).json({ success: false, error: 'Product not found.' });

  const keys = db.license_keys.filter(k => k.product_id === id);
  return res.json({ success: true, keys });
});

apiRouter.post('/products/:id/licenses/bulk', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { rawKeys } = req.body; // Newline separated keys

    const product = db.products.find(p => p.id === id);
    if (!product || !assertOwnership(user, product.owner_id)) return res.status(404).json({ success: false, error: 'Product not found.' });

    const keyList = String(rawKeys || '')
      .split('\n')
      .map(k => k.trim())
      .filter(k => k.length > 0);

    if (keyList.length === 0) {
      return res.status(400).json({ success: false, error: 'Please provide at least one valid license key.' });
    }

    const nowStr = new Date().toISOString();
    let addedCount = 0;

    for (const key of keyList) {
      // Prevent duplicates in same product
      const exists = db.license_keys.find(k => k.product_id === id && k.license_key === key);
      if (!exists) {
        db.license_keys.push({
          id: `key-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          owner_id: user.id,
          product_id: id,
          license_key: key,
          is_redeemed: false,
          created_at: nowStr
        });
        addedCount++;
      }
    }

    // Update product stock count
    const totalAvailable = db.license_keys.filter(k => k.product_id === id && !k.is_redeemed).length;
    product.stock_count = totalAvailable;

    db.saveImmediately();
    return res.json({ success: true, addedCount, totalAvailable });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Secure Digital File Upload
apiRouter.post('/products/:id/upload-file', authenticate, upload.single('file'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ success: false, error: 'No file uploaded.' });
    }

    const product = db.products.find(p => p.id === id);
    if (!product || !assertOwnership(user, product.owner_id)) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }

    // Remove old file record if exists
    db.digital_files = db.digital_files.filter(f => f.product_id !== id);

    const token = CryptoService.generateRandomToken(20);
    const digitalFileRecord: DigitalFile = {
      id: `df-${Date.now()}`,
      owner_id: user.id,
      product_id: id,
      original_filename: file.originalname,
      stored_filename: file.filename,
      file_size: file.size,
      mime_type: file.mimetype,
      download_token: token,
      created_at: new Date().toISOString()
    };

    db.digital_files.push(digitalFileRecord);
    product.delivery_type = 'DIGITAL_FILE';
    product.stock_count = 9999; // Digital file has unlimited stock

    logAudit({
      userId: user.id,
      action: 'DIGITAL_FILE_UPLOADED',
      resourceType: 'DIGITAL_FILE',
      resourceId: digitalFileRecord.id,
      metadata: { originalName: file.originalname, size: file.size },
      req
    });

    db.saveImmediately();
    return res.json({ success: true, file: digitalFileRecord });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Product Categories CRUD
apiRouter.get('/categories', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { bot_id } = req.query;
  let categories = db.product_categories.filter(c => c.owner_id === user.id);
  if (bot_id) categories = categories.filter(c => c.bot_id === String(bot_id));
  return res.json({ success: true, categories });
});

apiRouter.post('/categories', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { bot_id, name, description } = req.body;
    if (!bot_id || !name) return res.status(400).json({ success: false, error: 'Bot ID and category name required.' });

    const newCat: ProductCategory = {
      id: `cat-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      owner_id: user.id,
      bot_id,
      name: String(name).trim(),
      description: description || '',
      is_active: true,
      created_at: new Date().toISOString()
    };

    db.product_categories.push(newCat);
    db.saveImmediately();
    return res.json({ success: true, category: newCat });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.put('/categories/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { name, description, is_active } = req.body;

    const cat = db.product_categories.find(c => c.id === id);
    if (!cat || !assertOwnership(user, cat.owner_id)) return res.status(404).json({ success: false, error: 'Category not found.' });

    if (name !== undefined) cat.name = String(name).trim();
    if (description !== undefined) cat.description = description;
    if (is_active !== undefined) cat.is_active = !!is_active;

    db.saveImmediately();
    return res.json({ success: true, category: cat });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/categories/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;

    const index = db.product_categories.findIndex(c => c.id === id);
    if (index === -1) return res.status(404).json({ success: false, error: 'Category not found.' });

    const cat = db.product_categories[index];
    if (!assertOwnership(user, cat.owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

    db.product_categories.splice(index, 1);
    db.saveImmediately();

    return res.json({ success: true, message: 'Category deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 6. ORDERS & TRANSACTIONS
// ==========================================

apiRouter.get('/orders', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const isSuperAdmin = user.role === 'SUPER ADMIN' || user.role === 'ADMIN';
    const { status, bot_id, search } = req.query;

    let orders = isSuperAdmin ? db.orders : db.orders.filter(o => o.owner_id === user.id);

    if (bot_id) orders = orders.filter(o => o.bot_id === String(bot_id));
    if (status) orders = orders.filter(o => o.status === String(status));
    if (search) {
      const q = String(search).toLowerCase();
      orders = orders.filter(o =>
        o.id.toLowerCase().includes(q) ||
        o.customer_name.toLowerCase().includes(q) ||
        o.product_name.toLowerCase().includes(q)
      );
    }

    return res.json({ success: true, orders });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/orders/:id/refund', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const order = db.orders.find(o => o.id === id);

    if (!order || !assertOwnership(user, order.owner_id)) {
      return res.status(404).json({ success: false, error: 'Order not found.' });
    }

    order.status = 'REFUNDED';
    order.updated_at = new Date().toISOString();

    // Adjust customer stats
    const customer = db.customers.find(c => c.id === order.customer_id);
    if (customer) {
      customer.total_spent = Math.max(0, customer.total_spent - order.total_amount);
    }

    logAudit({
      userId: user.id,
      action: 'ORDER_REFUNDED',
      resourceType: 'ORDER',
      resourceId: id,
      req
    });

    db.saveImmediately();
    return res.json({ success: true, message: 'Order marked as refunded.', order });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Secure Download Route
apiRouter.get('/downloads/:orderId/:token', async (req: Request, res: Response) => {
  try {
    const { orderId } = req.params;
    const order = db.orders.find(o => o.id === orderId);

    if (!order || (order.status !== 'DELIVERED' && order.status !== 'PAID')) {
      return res.status(403).send('Unauthorized download request.');
    }

    const digitalFile = db.digital_files.find(f => f.product_id === order.product_id);
    if (!digitalFile) {
      return res.status(404).send('Digital file asset not found.');
    }

    const fullPath = path.join(uploadDir, digitalFile.stored_filename);
    if (!fs.existsSync(fullPath)) {
      // Stream fallback content for demo assets
      res.setHeader('Content-Disposition', `attachment; filename="${digitalFile.original_filename}"`);
      res.setHeader('Content-Type', 'text/plain');
      return res.send(`TeleSell Digital Asset\nOrder: ${order.id}\nItem: ${order.product_name}\nThank you for your purchase!`);
    }

    res.setHeader('Content-Disposition', `attachment; filename="${digitalFile.original_filename}"`);
    res.setHeader('Content-Type', digitalFile.mime_type || 'application/octet-stream');
    const fileStream = fs.createReadStream(fullPath);
    fileStream.pipe(res);
  } catch (err: any) {
    res.status(500).send('Download failed.');
  }
});

// ==========================================
// 7. CUSTOMERS CRM
// ==========================================

apiRouter.get('/customers', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const isSuperAdmin = user.role === 'SUPER ADMIN' || user.role === 'ADMIN';
  const { bot_id } = req.query;

  let customers = isSuperAdmin ? db.customers : db.customers.filter(c => c.owner_id === user.id);
  if (bot_id) customers = customers.filter(c => c.bot_id === String(bot_id));

  return res.json({ success: true, customers });
});

apiRouter.post('/customers/:id/wallet', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const { amount, action } = req.body; // action: 'ADD' or 'DEDUCT'

    const customer = db.customers.find(c => c.id === id);
    if (!customer || !assertOwnership(user, customer.owner_id)) return res.status(404).json({ success: false, error: 'Customer not found.' });

    const delta = Math.abs(Number(amount) || 0);
    if (action === 'DEDUCT') {
      customer.wallet_balance = Math.max(0, customer.wallet_balance - delta);
    } else {
      customer.wallet_balance += delta;
    }
    customer.updated_at = new Date().toISOString();

    db.saveImmediately();
    return res.json({ success: true, customer });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 8. BROADCAST & MARKETING
// ==========================================

apiRouter.get('/broadcasts', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { bot_id } = req.query;
  let broadcasts = db.broadcasts.filter(b => b.owner_id === user.id);
  if (bot_id) broadcasts = broadcasts.filter(b => b.bot_id === String(bot_id));
  return res.json({ success: true, broadcasts });
});

apiRouter.post('/broadcasts', authenticate, requireActiveSubscription, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { bot_id, title, message_type, message_text, media_url, target_audience, buttons_json } = req.body;

    if (!bot_id || !title || !message_text) {
      return res.status(400).json({ success: false, error: 'Bot ID, campaign title, and message text are required.' });
    }

    const bot = db.telegram_bots.find(b => b.id === bot_id);
    if (!bot || !assertOwnership(user, bot.owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

    const broadcastId = `bc-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const newBroadcast: Broadcast = {
      id: broadcastId,
      owner_id: user.id,
      bot_id,
      title: String(title).trim(),
      message_type: message_type || 'TEXT',
      message_text: String(message_text).trim(),
      media_url: media_url || undefined,
      buttons_json: buttons_json || undefined,
      target_audience: target_audience || 'ALL',
      status: 'QUEUED',
      total_recipients: 0,
      sent_count: 0,
      failed_count: 0,
      created_at: new Date().toISOString()
    };

    db.broadcasts.unshift(newBroadcast);
    db.saveImmediately();

    // Trigger async broadcast worker in background!
    TelegramService.executeBroadcast(broadcastId).catch(err => console.error('Broadcast worker error:', err));

    return res.json({ success: true, broadcast: newBroadcast });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/broadcasts/:id/cancel', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const broadcast = db.broadcasts.find(b => b.id === id);
  if (!broadcast || !assertOwnership(user, broadcast.owner_id)) return res.status(404).json({ success: false, error: 'Broadcast not found.' });

  broadcast.status = 'CANCELLED';
  db.saveImmediately();
  return res.json({ success: true, message: 'Broadcast campaign cancelled.' });
});

// ==========================================
// 9. COUPONS & PROMOTIONS
// ==========================================

apiRouter.get('/coupons', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const coupons = db.coupons.filter(c => c.owner_id === user.id);
  return res.json({ success: true, coupons });
});

apiRouter.post('/coupons', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { bot_id, code, discount_type, discount_value, max_uses, min_order_amount } = req.body;

    if (!bot_id || !code || discount_value === undefined) {
      return res.status(400).json({ success: false, error: 'Bot ID, Coupon Code, and Discount Value are required.' });
    }

    const newCoupon: Coupon = {
      id: `cpn-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      owner_id: user.id,
      bot_id,
      code: String(code).trim().toUpperCase(),
      discount_type: discount_type === 'FIXED' ? 'FIXED' : 'PERCENTAGE',
      discount_value: Number(discount_value),
      max_uses: Number(max_uses) || 100,
      current_uses: 0,
      min_order_amount: Number(min_order_amount) || 0,
      is_active: true,
      created_at: new Date().toISOString()
    };

    db.coupons.unshift(newCoupon);
    db.saveImmediately();
    return res.json({ success: true, coupon: newCoupon });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/coupons/:id', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = req.user!;
  const index = db.coupons.findIndex(c => c.id === id);
  if (index === -1) return res.status(404).json({ success: false, error: 'Coupon not found.' });
  if (!assertOwnership(user, db.coupons[index].owner_id)) return res.status(403).json({ success: false, error: 'Forbidden.' });

  db.coupons.splice(index, 1);
  db.saveImmediately();
  return res.json({ success: true, message: 'Coupon removed.' });
});

// ==========================================
// 10. REFERRALS & RESELLER NETWORK
// ==========================================

apiRouter.get('/referrals/stats', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const userReferrals = db.referrals.filter(r => r.referrer_id === user.id);
  const totalEarnings = userReferrals.reduce((sum, r) => sum + r.commission_amount, 0);

  return res.json({
    success: true,
    code: user.referral_code,
    link: `${process.env.APP_URL || ''}/register?ref=${user.referral_code}`,
    count: userReferrals.length,
    totalEarnings,
    referrals: userReferrals
  });
});

apiRouter.post('/reseller/apply', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { business_name, telegram_handle, experience_info } = req.body;

    if (!business_name || !telegram_handle) {
      return res.status(400).json({ success: false, error: 'Business name and Telegram handle are required.' });
    }

    let app = db.reseller_applications.find(a => a.user_id === user.id);
    const nowStr = new Date().toISOString();

    if (app) {
      app.business_name = business_name;
      app.telegram_handle = telegram_handle;
      app.experience_info = experience_info || '';
      app.status = 'PENDING';
      app.updated_at = nowStr;
    } else {
      app = {
        id: `res-${Date.now()}`,
        user_id: user.id,
        user_name: user.full_name,
        user_email: user.email,
        business_name,
        telegram_handle,
        experience_info: experience_info || '',
        status: 'PENDING',
        commission_rate: 20,
        total_sales: 0,
        total_earnings: 0,
        balance: 0,
        created_at: nowStr,
        updated_at: nowStr
      };
      db.reseller_applications.push(app);
    }

    user.reseller_status = 'PENDING';
    db.saveImmediately();

    return res.json({ success: true, application: app, message: 'Reseller application submitted for review.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 11. ADMIN PANEL (Protected: ADMIN / SUPER ADMIN)
// ==========================================

apiRouter.get('/admin/stats', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (_req: AuthenticatedRequest, res: Response) => {
  const totalUsers = db.users.length;
  const activeSubs = db.subscriptions.filter(s => s.status === 'ACTIVE').length;
  const expiredSubs = db.subscriptions.filter(s => s.status === 'EXPIRED').length;
  const totalBots = db.telegram_bots.length;
  const totalProducts = db.products.length;
  const totalOrders = db.orders.length;
  const totalPlatformRevenue = db.payments.filter(p => p.status === 'SUCCESS').reduce((sum, p) => sum + p.amount, 0);

  return res.json({
    success: true,
    stats: {
      totalUsers,
      activeSubs,
      expiredSubs,
      totalBots,
      totalProducts,
      totalOrders,
      totalPlatformRevenue,
      plansCount: db.subscription_plans.length,
      auditLogsCount: db.audit_logs.length
    }
  });
});

apiRouter.get('/admin/users', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (_req: AuthenticatedRequest, res: Response) => {
  const safeUsers = db.users.map(u => {
    const sub = db.subscriptions.find(s => s.user_id === u.id && s.status === 'ACTIVE');
    const botsCount = db.telegram_bots.filter(b => b.owner_id === u.id).length;
    return {
      id: u.id,
      email: u.email,
      full_name: u.full_name,
      role: u.role,
      reseller_status: u.reseller_status,
      reseller_commission_rate: u.reseller_commission_rate,
      reseller_balance: u.reseller_balance,
      active_subscription: sub || null,
      bots_count: botsCount,
      created_at: u.created_at
    };
  });
  return res.json({ success: true, users: safeUsers });
});

apiRouter.put('/admin/users/:id/role', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { role, reseller_status, reseller_commission_rate } = req.body;
    const adminUser = req.user!;

    const targetUser = db.users.find(u => u.id === id);
    if (!targetUser) return res.status(404).json({ success: false, error: 'User not found.' });

    // Super Admin role change restriction
    if (targetUser.role === 'SUPER ADMIN' && adminUser.role !== 'SUPER ADMIN') {
      return res.status(403).json({ success: false, error: 'Only Super Admin can modify Super Admin accounts.' });
    }

    if (role) targetUser.role = role;
    if (reseller_status) targetUser.reseller_status = reseller_status;
    if (reseller_commission_rate !== undefined) targetUser.reseller_commission_rate = Number(reseller_commission_rate);
    targetUser.updated_at = new Date().toISOString();

    logAudit({
      userId: adminUser.id,
      action: 'ADMIN_USER_ROLE_UPDATED',
      resourceType: 'USER',
      resourceId: targetUser.id,
      metadata: { newRole: role, newResellerStatus: reseller_status },
      req
    });

    db.saveImmediately();
    return res.json({ success: true, user: targetUser });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/admin/resellers', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (_req: AuthenticatedRequest, res: Response) => {
  return res.json({ success: true, applications: db.reseller_applications });
});

apiRouter.put('/admin/resellers/:id/status', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, commission_rate, notes } = req.body;
    const app = db.reseller_applications.find(a => a.id === id);
    if (!app) return res.status(404).json({ success: false, error: 'Application not found.' });

    app.status = status;
    if (commission_rate !== undefined) app.commission_rate = Number(commission_rate);
    if (notes) app.notes = notes;
    app.updated_at = new Date().toISOString();

    const user = db.users.find(u => u.id === app.user_id);
    if (user) {
      user.reseller_status = status;
      if (status === 'APPROVED') {
        user.role = 'RESELLER';
        user.reseller_commission_rate = app.commission_rate;
      }
    }

    db.saveImmediately();
    return res.json({ success: true, application: app });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/admin/audit-logs', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (req: AuthenticatedRequest, res: Response) => {
  const { search } = req.query;
  let logs = db.audit_logs;
  if (search) {
    const q = String(search).toLowerCase();
    logs = logs.filter(l => l.action.toLowerCase().includes(q) || l.resource_type.toLowerCase().includes(q));
  }
  return res.json({ success: true, logs: logs.slice(0, 100) });
});

apiRouter.get('/admin/settings', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (_req: AuthenticatedRequest, res: Response) => {
  return res.json({ success: true, settings: db.system_settings });
});

apiRouter.put('/admin/settings', authenticate, requireRole('ADMIN', 'SUPER ADMIN'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { settings } = req.body; // array of { key, value }
    if (Array.isArray(settings)) {
      const nowStr = new Date().toISOString();
      for (const item of settings) {
        const existing = db.system_settings.find(s => s.key === item.key);
        if (existing) {
          existing.value = String(item.value);
          existing.updated_at = nowStr;
        } else {
          db.system_settings.push({
            id: `set-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            key: item.key,
            value: String(item.value),
            updated_at: nowStr
          });
        }
      }
      db.saveImmediately();
    }
    return res.json({ success: true, settings: db.system_settings });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Notifications
apiRouter.get('/notifications', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const notifs = db.notifications.filter(n => n.user_id === user.id).slice(0, 30);
  return res.json({ success: true, notifications: notifs });
});

apiRouter.put('/notifications/read-all', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  for (const n of db.notifications) {
    if (n.user_id === user.id) n.is_read = true;
  }
  db.save();
  return res.json({ success: true });
});
